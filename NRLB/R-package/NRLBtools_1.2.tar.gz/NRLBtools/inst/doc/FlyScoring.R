## -----------------------------------------------------------------------------
library(NRLBtools)
NRLBtools::model.info()

## -----------------------------------------------------------------------------
NRLBtools::logo(nrlb.model = 16)

## -----------------------------------------------------------------------------
NRLBtools::model.info(nrlb.model = 16)

## -----------------------------------------------------------------------------
enh = as.character(BSgenome.Dmelanogaster.UCSC.dm3::BSgenome.Dmelanogaster.UCSC.dm3$chrX[4915195:4915486])

## ---- fig.show='asis'---------------------------------------------------------
NRLBtools::score.seq(sequence = enh, nrlb.model = 16, plot = TRUE, nPeaks = 10, annotate = TRUE)

## -----------------------------------------------------------------------------
max = NRLBtools::load.models(fileName = system.file("extdata", "MAX-NRLBConfig.csv", package = "NRLBtools"))

## -----------------------------------------------------------------------------
NRLBtools::model.info(models = max)

## -----------------------------------------------------------------------------
NRLBtools::model.info(models = max, index = 8)

## -----------------------------------------------------------------------------
NRLBtools::logo(models = max, index = 8)

## -----------------------------------------------------------------------------
NRLBtools::score.seq(sequence = enh, models = max, index = 8, plot = T)

