.onLoad <- function(libname, pkgname){
  packageStartupMessage("Welcome to the NRLBtools package")
}